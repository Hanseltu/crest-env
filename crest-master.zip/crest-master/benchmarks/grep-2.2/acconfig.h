/* Define to use grep's error-checking malloc in the kwset routines.  */
#undef GREP

/* Package name. */
#undef PACKAGE

/* Version number. */
#undef VERSION

/*
 * Internationalization stuffs.
 */

#undef HAVE_STPCPY

#undef ENABLE_NLS

#undef HAVE_CATGETS

#undef HAVE_GETTEXT

#undef HAVE_LC_MESSAGES
